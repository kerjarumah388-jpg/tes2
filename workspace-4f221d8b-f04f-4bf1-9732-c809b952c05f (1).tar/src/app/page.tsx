'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'

export default function Home() {
  const [display, setDisplay] = useState('0')
  const [previousValue, setPreviousValue] = useState<string | null>(null)
  const [operation, setOperation] = useState<string | null>(null)
  const [resetDisplay, setResetDisplay] = useState(false)

  const handleNumberClick = (value: string) => {
    if (resetDisplay) {
      setDisplay(value)
      setResetDisplay(false)
    } else {
      setDisplay(display === '0' ? value : display + value)
    }
  }

  const handleOperationClick = (op: string) => {
    if (operation && !resetDisplay) {
      calculate()
    }
    setPreviousValue(display)
    setOperation(op)
    setResetDisplay(true)
  }

  const calculate = () => {
    if (!previousValue || !operation) return

    const prev = parseFloat(previousValue)
    const current = parseFloat(display)
    let result = 0

    switch (operation) {
      case '+':
        result = prev + current
        break
      case '-':
        result = prev - current
        break
      case '×':
        result = prev * current
        break
      case '÷':
        result = current !== 0 ? prev / current : 0
        break
      default:
        return
    }

    // Handle decimal precision
    const formattedResult = Number.isInteger(result) ? result.toString() : result.toFixed(8).replace(/\.?0+$/, '')
    setDisplay(formattedResult)
    setPreviousValue(null)
    setOperation(null)
    setResetDisplay(true)
  }

  const handleClear = () => {
    setDisplay('0')
    setPreviousValue(null)
    setOperation(null)
    setResetDisplay(false)
  }

  const handleDelete = () => {
    if (display.length === 1 || (display.length === 2 && display.startsWith('-'))) {
      setDisplay('0')
    } else {
      setDisplay(display.slice(0, -1))
    }
  }

  const handleDecimal = () => {
    if (resetDisplay) {
      setDisplay('0.')
      setResetDisplay(false)
    } else if (!display.includes('.')) {
      setDisplay(display + '.')
    }
  }

  const handlePercentage = () => {
    const value = parseFloat(display)
    const result = value / 100
    setDisplay(Number.isInteger(result) ? result.toString() : result.toFixed(8).replace(/\.?0+$/, ''))
  }

  const buttonStyle = 'text-2xl font-semibold h-16 transition-all hover:scale-105 active:scale-95'
  const operationStyle = 'text-xl font-semibold h-16 transition-all hover:scale-105 active:scale-95 bg-primary text-primary-foreground hover:bg-primary/90'

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-800">
      <main className="flex-1 flex items-center justify-center p-4">
        <Card className="w-full max-w-sm shadow-2xl">
          <CardContent className="p-6 space-y-4">
            {/* Header */}
            <div className="text-center mb-4">
              <h1 className="text-2xl font-bold text-primary">Kalkulator</h1>
              <p className="text-sm text-muted-foreground mt-1">Kalkulator Sederhana</p>
            </div>

            {/* Display */}
            <div className="bg-muted rounded-lg p-6 text-right">
              {operation && previousValue && (
                <div className="text-sm text-muted-foreground mb-1 h-6">
                  {previousValue} {operation}
                </div>
              )}
              <div className="text-4xl font-bold text-foreground break-all">
                {display}
              </div>
            </div>

            {/* Buttons Grid */}
            <div className="grid grid-cols-4 gap-3">
              {/* Row 1 */}
              <Button
                variant="outline"
                className={buttonStyle}
                onClick={handleClear}
              >
                C
              </Button>
              <Button
                variant="outline"
                className={buttonStyle}
                onClick={handleDelete}
              >
                ⌫
              </Button>
              <Button
                variant="outline"
                className={buttonStyle}
                onClick={handlePercentage}
              >
                %
              </Button>
              <Button
                variant="outline"
                className={operationStyle}
                onClick={() => handleOperationClick('÷')}
              >
                ÷
              </Button>

              {/* Row 2 */}
              <Button
                variant="outline"
                className={buttonStyle}
                onClick={() => handleNumberClick('7')}
              >
                7
              </Button>
              <Button
                variant="outline"
                className={buttonStyle}
                onClick={() => handleNumberClick('8')}
              >
                8
              </Button>
              <Button
                variant="outline"
                className={buttonStyle}
                onClick={() => handleNumberClick('9')}
              >
                9
              </Button>
              <Button
                variant="outline"
                className={operationStyle}
                onClick={() => handleOperationClick('×')}
              >
                ×
              </Button>

              {/* Row 3 */}
              <Button
                variant="outline"
                className={buttonStyle}
                onClick={() => handleNumberClick('4')}
              >
                4
              </Button>
              <Button
                variant="outline"
                className={buttonStyle}
                onClick={() => handleNumberClick('5')}
              >
                5
              </Button>
              <Button
                variant="outline"
                className={buttonStyle}
                onClick={() => handleNumberClick('6')}
              >
                6
              </Button>
              <Button
                variant="outline"
                className={operationStyle}
                onClick={() => handleOperationClick('-')}
              >
                −
              </Button>

              {/* Row 4 */}
              <Button
                variant="outline"
                className={buttonStyle}
                onClick={() => handleNumberClick('1')}
              >
                1
              </Button>
              <Button
                variant="outline"
                className={buttonStyle}
                onClick={() => handleNumberClick('2')}
              >
                2
              </Button>
              <Button
                variant="outline"
                className={buttonStyle}
                onClick={() => handleNumberClick('3')}
              >
                3
              </Button>
              <Button
                variant="outline"
                className={operationStyle}
                onClick={() => handleOperationClick('+')}
              >
                +
              </Button>

              {/* Row 5 */}
              <Button
                variant="outline"
                className={`${buttonStyle} col-span-2`}
                onClick={() => handleNumberClick('0')}
              >
                0
              </Button>
              <Button
                variant="outline"
                className={buttonStyle}
                onClick={handleDecimal}
              >
                .
              </Button>
              <Button
                className={operationStyle}
                onClick={calculate}
              >
                =
              </Button>
            </div>
          </CardContent>
        </Card>
      </main>

      {/* Footer */}
      <footer className="mt-auto p-4 text-center text-sm text-muted-foreground">
        <p>&copy; 2024 Kalkulator Sederhana</p>
      </footer>
    </div>
  )
}
